// Definindo variáveis globais
let jardineiro;
let plantas = [];
let temperatura = 10;
let totalArvores = 0;

// Definição mínima da classe Jardineiro
class Jardineiro {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.velocidade = 5;
    this.size = 40;
  }
  atualizar() {
    if (keyIsDown(LEFT_ARROW))  this.x -= this.velocidade;
    if (keyIsDown(RIGHT_ARROW)) this.x += this.velocidade;
    if (keyIsDown(UP_ARROW))    this.y -= this.velocidade;
    if (keyIsDown(DOWN_ARROW))  this.y += this.velocidade;
    this.x = constrain(this.x, this.size/2, width - this.size/2);
    this.y = constrain(this.y, this.size/2, height - this.size/2);
  }
  mostrar() {
    fill(80, 50, 20);
    rectMode(CENTER);
    rect(this.x, this.y, this.size * 0.6, this.size);
    fill(200, 180, 140);
    ellipse(this.x, this.y - this.size * 0.6, this.size * 0.6);
  }
}

function setup() {
  createCanvas(600, 400);
  jardineiro = new Jardineiro(width / 2, height - 50);
}

function draw() {
  // Usando map() para ajustar a cor de fundo de forma mais controlada
  let corFundo = lerpColor(
    color(217, 112, 26),
    color(219, 239, 208),
    map(totalArvores, 0, 100, 0, 1)
  );
  background(corFundo);

  mostrarInformacoes();

  temperatura += 0.1;

  jardineiro.atualizar();
  jardineiro.mostrar();

  // Verifica se o jogo acabou
  verificarFimDeJogo();

  // Usando map() para aplicar o comportamento de árvores plantadas
  plantas.map((arvore) => arvore.mostrar());
}

// Função para mostrar as informações na tela
function mostrarInformacoes() {
  textSize(16);
  fill(0);
}

// Evita o erro “verificarFimDeJogo is not defined”
function verificarFimDeJogo() {
  // implemente aqui sua condição de fim de jogo
}
